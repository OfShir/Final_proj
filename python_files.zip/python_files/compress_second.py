import random
import os

def chunk_to_bit_mask(chunk):
    bit_mask = 0
    i = 0
    while (i < len(chunk)):
        byte = chunk[i:i+2]
        if int(byte, 16) == 0:
            bit_mask += 0
        elif 0 < int(byte, 16) < 16:
            bit_mask += pow(2,len(chunk)-i-2)  #adding to bitmask '01'
        elif 255 >= int(byte, 16) >= 240:
            bit_mask += pow(2,len(chunk)-i-1) #adding to bitmask '10'
        else:
            bit_mask += pow(2,(len(chunk)-i-1))
            bit_mask += pow(2,(len(chunk)-i-2)) #adding to bitmask '11'
        i += 2
    return f"{bit_mask:02X}"

def chunk_to_non_zero_values(chunk, output_file):
    i = 0
    non_zero_values = []
    k = 0
    while(i < len(chunk)):
        value = chunk[i:i+2]
        if (value != '00'):
            non_zero_values.append(value)
            k += 1
        i +=2
    for i in range(0, k):
        val_to_write = int(non_zero_values[i], 16)
        if val_to_write > 0 and val_to_write < 16:
            output_file.write(f"{val_to_write:1X}")
        elif val_to_write >= 240 and val_to_write <= 255:
            val_to_write = val_to_write - 240
            output_file.write(f"{(val_to_write):1X}")
        else:
            output_file.write(f"{val_to_write:2X}")
    return



def chunk_and_write_file(filename, chunk_size, output_filename):
    with open(filename, "r") as input_file:
        with open(output_filename, "w") as output_file:
            while True:
                chunk = input_file.read(chunk_size)
                if not chunk:
                    break
                bit_mask = chunk_to_bit_mask(chunk)
                output_file.write(str(bit_mask))
                chunk_to_non_zero_values(chunk, output_file)


def decompress_file(compressed_file, decompressed_file):
    with open(compressed_file, 'r') as input_file, open(decompressed_file, 'w') as output_file:
        while True:
            chunk = input_file.read(2)
            if not chunk:
                break
            bit_mask = bin(int(chunk, 16))[2:].zfill(8)
            for i in range(0, 8, 2):
                if bit_mask[i:i+2] == '00':
                    output_file.write('00')
                elif bit_mask[i:i+2] == '01':
                    output_file.write('0')
                    next_string = input_file.read(1)
                    output_file.write(next_string)
                elif bit_mask[i:i + 2] == '10':
                    next_string = input_file.read(1)
                    if next_string:
                        val = int(next_string, 16) + 240
                        output_file.write(hex(val)[2:].upper())
                else:
                    next_string = input_file.read(2)
                    output_file.write(next_string)


# def create_new_file(sparsity=0.0, size=10240*5, filename="new_file.txt"):
#     with open(filename, "wb") as f:
#         for i in range(int(size / 8)): # 4 bytes per number
#             if random.random() > sparsity:
#                 x = random.randint(-128, 127)
#                 while (x == 0):
#                     x = random.randint(-128, 127)
#                 val = (twosCom_decBin(x, 8))
#                 f.write((val.encode()))
#             else:
#                 x = 0
#                 val = (twosCom_decBin(x, 8))
#                 f.write((val.encode()))

def create_new_file(sparsity=0.99, size=10240, filename="new_file.txt", percentage=0.9):
    with open(filename, "w") as f:
        for i in range(size):
            y = random.random()
            if y > sparsity:
                if y < percentage:
                    x = random.randint(-15, 15)
                else:
                    x = random.randint(-128, 127)
                while x == 0:
                    x = random.randint(-128, 127)
                x_hex = hex(x & 0xff)[2:].zfill(2).upper()
                f.write(x_hex)
            else:
                f.write("00")

def twosCom_decBin(dec, digit):
    if dec >= 0:
        bin1 = bin(dec)[2:].zfill(digit)
        return bin1
    else:
        bin1 = bin(-dec - 1)[2:].zfill(digit)
        neg_bin = ''.join(['1' if x == '0' else '0' for x in bin1])
        return neg_bin

def test_compression():
    for i in range(1, 6):
        filename = f"new_file{i}.txt"
        output_filename = f"output{i}.txt"
        decompressed_file = f"decompressed{i}.txt"
        create_new_file(filename=filename)

        original_size = os.path.getsize(filename)

        chunk_and_write_file(filename, 8, output_filename)
        compressed_size = os.path.getsize(output_filename)

        decompress_file(output_filename, decompressed_file)
        decompressed_size = os.path.getsize(decompressed_file)

        compression_ratio = compressed_size / decompressed_size

        print(f"File {i}:")
        print(f"Original size: {original_size} bytes")
        print(f"Compressed size: {compressed_size} bytes")
        print(f"Decompressed size: {decompressed_size} bytes")
        print(f"Compression ratio: {compression_ratio:.4f}")

test_compression()

# code that might work with some modifications. trying to write the code here.
# # import random
# # import os
# #
# # def chunk_to_bit_mask(chunk, output_file):
# #     bit_list = []
# #     bit_mask = 0
# #     for i, value in enumerate(chunk):
# #         if value != '0':
# #             bit_list.append(1)
# #         else:
# #             bit_list.append(0)
# #     for i in range(0, len(bit_list)):
# #         bit_mask += (bit_list[i])*(pow(2,(15-i)))
# #     if bit_mask == 0:
# #         output_file.write('00')
# #         hex_mask = '{:04x}'.format(bit_mask)
# #         return hex_mask
# #     elif bit_mask < 2**3:
# #         output_file.write('10')
# #         hex_mask = '{:04x}'.format(bit_mask)
# #         return hex_mask
# #     else:
# #         output_file.write('11')
# #         hex_mask = '{:04x}'.format(bit_mask)
# #         return hex_mask
# #
# # def chunk_to_non_zero_values(chunk, output_file):
# #     non_zero_values = [value for value in chunk if value != '0']
# #     for i in range(0, len(non_zero_values)):
# #         output_file.write(str(non_zero_values[i]))
# #     return
# #
# # def chunk_and_write_file(filename, chunk_size, output_filename):
# #     with open(filename, "r") as input_file:
# #         with open(output_filename, "w") as output_file:
# #             while True:
# #                 chunk = input_file.read(chunk_size)
# #                 if not chunk:
# #                     break
# #                 bit_mask = chunk_to_bit_mask(chunk,output_file)
# #                 output_file.write(str(bit_mask))
# #                 chunk_to_non_zero_values(chunk, output_file)
# #
# # def decompress_file(compressed_file, decompressed_file):
# #     with open(compressed_file, 'rb') as input_file, open(decompressed_file, 'wb') as output_file:
# #         while True:
# #             bit = input_file.read(1)
# #             if not bit:
# #                 break
# #             if bit == b'0':
# #                 output_file.write(b'0' * 16)
# #                 input_file.read(5)
# #             else:
# #                 bit = input_file.read(1)
# #                 if bit == b'0':
# #                     chunk = input_file.read(4)
# #                     binary = bin(int(chunk, 16))[2:].zfill(16)
# #                     for char in binary:
# #                         if char == '1':
# #                             next_string = input_file.read(1)
# #                             output_file.write(next_string)
# #                         else:
# #                             output_file.write(b'0')
# #                 elif bit == b'1':
# #                     chunk = input_file.read(4)
# #                     binary = bin(int(chunk, 16))[2:].zfill(16)
# #                     for char in binary:
# #                         if char == '1':
# #                             next_string = input_file.read(1)
# #                             output_file.write(next_string)
# #                         else:
# #                             output_file.write(b'0')
# #
# # # def create_new_file(sparsity=0.5, size=10240, filename="new_file.txt"):
# # #     with open(filename, "w") as f:
# # #         for i in range(int(size / 4)): # 4 bytes per number
# # #             if random.random() > sparsity:
# # #                 f.write(str(random.randint(0, 255)))
# # #             else:
# # #                 f.write('0')
# #
# # def create_new_file(sparsity=0.5, size=10240*10, filename="new_file.txt"):
# #     with open(filename, "wb") as f:
# #         for i in range(int(size / 8)): # 8 bytes per number
# #             if random.random() > sparsity:
# #                 x = random.randint(-128, 127)
# #                 while (x == 0):
# #                     x = random.randint(-128, 127)
# #                 val = (twosCom_decBin(x, 8))
# #                 f.write((val.encode()))
# #             else:
# #                 x = 0
# #                 val = (twosCom_decBin(x, 8))
# #                 f.write((val.encode()))
# #
# # def twosCom_decBin(dec, digit):
# #     if dec >= 0:
# #         bin1 = bin(dec)[2:].zfill(digit)
# #         return bin1
# #     else:
# #         bin1 = bin(-dec - 1)[2:].zfill(digit)
# #         neg_bin = ''.join(['1' if x == '0' else '0' for x in bin1])
# #         return neg_bin
# #
# # def test_compression():
# #     for i in range(1, 6):
# #         filename = f"new_file{i}.txt"
# #         output_filename = f"output{i}.txt"
# #         decompressed_file = f"decompressed{i}.txt"
# #         # create_new_file(filename=filename)
# #
# #         original_size = os.path.getsize(filename)
# #
# #         chunk_and_write_file(filename, 16, output_filename)
# #         compressed_size = os.path.getsize(output_filename)
# #
# #         decompress_file(output_filename, decompressed_file)
# #         decompressed_size = os.path.getsize(decompressed_file)
# #
# #         compression_ratio = compressed_size / decompressed_size
# #
# #         print(f"File {i}:")
# #         print(f"Original size: {original_size} bytes")
# #         print(f"Compressed size: {compressed_size} bytes")
# #         print(f"Decompressed size: {decompressed_size} bytes")
# #         print(f"Compression ratio: {compression_ratio:.4f}")
# #
# # test_compression()
# # # create_new_file()
# # # filename = "new_file.txt"
# # # output_filename = "output1.txt"
# # # decompressed_file = 'decompressed.txt'
# # # chunk_size = 16
# # #
# # # chunk_and_write_file(filename, 16, output_filename)
# # # decompress_file(output_filename,decompressed_file)
# import random
# import os
#
#
# def chunk_to_bit_mask(chunk, output_file):
#     bit_mask = 0
#     i = 0
#     while (i < len(chunk)):
#         value = int(chunk[i:i+2], 16)
#         if value == 0:
#             bit_mask += 0
#         elif 0 < value < 16:
#             bit_mask += 1 << (30 - i*2)
#             output_file.write(hex(value)[2:].zfill(2))
#         elif -128 <= value < -112:
#             bit_mask += 2 << (30 - i*2)
#             output_file.write(hex(value & 0xff)[2:].zfill(2))
#         else:
#             bit_mask += 3 << (30 - i*2)
#             output_file.write(hex(value)[2:].zfill(4))
#         i += 2
#     return hex(bit_mask)[2:].zfill(8)
#
#
# def chunk_to_values(chunk, output_file):
#     i = 0
#     while i < len(chunk):
#         value = int(chunk[i:i+2], 16)
#         if value == 0:
#             output_file.write('00')
#         elif 0 < value < 16:
#             output_file.write('01')
#             output_file.write(hex(value)[2:].zfill(1))
#         elif -128 <= value < -112:
#             output_file.write('10')
#             output_file.write(hex(value & 0xff)[2:].zfill(2))
#         else:
#             output_file.write('11')
#             output_file.write(hex(value)[2:].zfill(4))
#         i += 2
#
#
# def chunk_and_write_file(filename, chunk_size, output_filename):
#     with open(filename, "r") as input_file:
#         with open(output_filename, "w") as output_file:
#             while True:
#                 chunk = input_file.read(chunk_size)
#                 if not chunk:
#                     break
#                 bit_mask = chunk_to_bit_mask(chunk, output_file)
#                 output_file.write(bit_mask)
#                 chunk_to_values(chunk, output_file)
#
#
# def decompress_file(compressed_file, decompressed_file):
#     with open(compressed_file, 'r') as input_file, open(decompressed_file, 'w') as output_file:
#         while True:
#             bit_mask_chunk = input_file.read(8)
#             if not bit_mask_chunk:
#                 break
#             bit_mask
