
import random
import os
import struct
import time


def chunk_to_bit_mask(chunk, output_file):
    bit_mask = 0
    i = 0
    while (i<len(chunk)):
        flag = 0
        if ((chunk[i] != '0') or (chunk[i+1] !='0')):
            flag = 1
        bit_mask += (flag != 0)*pow(2,3-(i/2))
        i += 2
    bit_mask = int(bit_mask)
    return f"{bit_mask:01x}"

def chunk_to_non_zero_values(chunk, output_file):
    i = 0
    non_zero_values = []
    k = 0
    while (i < len(chunk)):
        value = chunk[i:i + 2]
        if (value != '00'):
            non_zero_values.append(value)
            k += 1
        i += 2
    for i in range(0, k):
        val_to_write = int(non_zero_values[i], 16)
        output_file.write(f"{val_to_write:02X}")
    return


def chunk_and_write_file(filename, chunk_size, output_filename):
    with open(filename, "r") as input_file:
        with open(output_filename, "w") as output_file:
            while True:
                chunk = input_file.read(chunk_size)
                if not chunk:
                    break
                bit_mask = chunk_to_bit_mask(chunk,output_file)
                output_file.write(str(bit_mask))
                chunk_to_non_zero_values(chunk, output_file)

def decompress_file(compressed_file, decompressed_file):
    with open(compressed_file, 'r') as input_file, open(decompressed_file, 'w') as output_file:
        while True:
            chunk = input_file.read(1)
            if len(chunk) < 1:
                break
            binary = bin(int(chunk, 16))[2:].zfill(4)
            for char in binary:
                if char == '1':
                    next_string = input_file.read(2)
                    output_file.write(next_string)
                else:
                    output_file.write('00')

def create_new_file(sparsity=0.9, size=10240, filename="new_file.txt", percentage=0.2):
    with open(filename, "w") as f:
        for i in range(size):
            y = random.random()
            if y > sparsity:
                if y < percentage:
                    x = random.randint(-15, 15)
                else:
                    x = random.randint(-128, 127)
                while x == 0:
                    x = random.randint(-128, 127)
                x_hex = hex(x & 0xff)[2:].zfill(2).upper()
                f.write(x_hex)
            else:
                f.write("00")

def twosCom_decBin(dec, digit):
    if dec >= 0:
        bin1 = bin(dec)[2:].zfill(digit)
        return bin1
    else:
        bin1 = bin(-dec - 1)[2:].zfill(digit)
        neg_bin = ''.join(['1' if x == '0' else '0' for x in bin1])
        return neg_bin

def test_compression():
    for i in range(1, 6):
        filename = f"new_file{i}.txt"
        output_filename = f"output{i}.txt"
        decompressed_file = f"decompressed{i}.txt"
        create_new_file(filename=filename)

        original_size = os.path.getsize(filename)

        start_time = time.time()
        chunk_and_write_file(filename, 8, output_filename)
        compression_time = time.time() - start_time

        compressed_size = os.path.getsize(output_filename)

        start_time = time.time()
        decompress_file(output_filename, decompressed_file)
        decompression_time = time.time() - start_time

        decompressed_size = os.path.getsize(decompressed_file)

        compression_ratio = compressed_size / decompressed_size

        print(f"File {i}:")
        print(f"Original size: {original_size} bytes")
        print(f"Compressed size: {compressed_size} bytes")
        print(f"Decompressed size: {decompressed_size} bytes")
        print(f"Compression ratio: {compression_ratio:.4f}")
        print(f"Compression time: {compression_time:.4f} seconds")
        print(f"Decompression time: {decompression_time:.4f} seconds")
        print()

test_compression()
