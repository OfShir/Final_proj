# import time
# import os
# import zlib
# import gzip
# import lzma
#
# # The file to be compressed
# file_name = "new_file1.txt"
#
# # Get the file size before compression
# before_size = os.stat(file_name).st_size
#
# # Compress the file using zlib
# start = time.perf_counter()
# zlib_compressed = zlib.compress(open(file_name, "rb").read())
# zlib_time = time.perf_counter() - start
# zlib_size = len(zlib_compressed)
# start_dec = time.perf_counter()
# decompressed_zlib = zlib.decompress(zlib_compressed)
# decompressed_zlib_size = len(decompressed_zlib)
# end = time.perf_counter()
# zlib_time_dec = end - start_dec
#
# # Compress the file using gzip
# start = time.perf_counter()
# gzip_compressed = gzip.compress(open(file_name, "rb").read())
# gzip_time = time.perf_counter() - start
# gzip_size = len(gzip_compressed)
# start_dec = time.perf_counter()
# decompressed_gzip = gzip.decompress(gzip_compressed)
# decompressed_gzip_size = len(decompressed_gzip)
# end = time.perf_counter()
# gzip_time_dec = end - start_dec
#
# # Compress the file using lzma
# start = time.perf_counter()
# lzma_compressed = lzma.compress(open(file_name, "rb").read())
# lzma_time = time.perf_counter() - start
# lzma_size = len(lzma_compressed)
# start_dec = time.perf_counter()
# decompressed_lzma = lzma.decompress(lzma_compressed)
# decompressed_lzma_size = len(decompressed_lzma)
# end = time.perf_counter()
# lzma_time_dec = end - start_dec
#
# # Print the results
# print("Original size:", before_size, "bytes")
#
# print("zlib compressed size:", zlib_size, "bytes")
# print("gzip compressed size:", gzip_size, "bytes")
# print("lzma compressed size:", lzma_size, "bytes")
#
# print("zlib compress time:", zlib_time, "seconds")
# print("gzip compress time:", gzip_time, "seconds")
# print("lzma compress time:", lzma_time, "seconds")
#
# print("zlib decompress size: {} bytes".format(decompressed_zlib_size))
# print("gzip decompress size: {} bytes".format(decompressed_gzip_size))
# print("lzma decompress size: {} bytes".format(decompressed_lzma_size))
#
# print("bzip time: {} seconds".format(zlib_time_dec))
# print("gzip time: {} seconds".format(gzip_time_dec))
# print("lzma time: {} seconds".format(lzma_time_dec))
#
# print("bzip compression ration: ", (zlib_size/before_size))
# print("gzip compression ration: ", (gzip_size/before_size))
# print("lzma compression ration: ", (lzma_size/before_size))

import numpy as np

def csr_compress(matrix):
    rows, cols = matrix.shape
    data, indices, indptr = [], [], []
    ptr = 0

    for i in range(rows):
        row = matrix[i]
        indptr.append(ptr)
        for j in range(cols):
            if row[j] != 0:
                data.append(row[j])
                indices.append(j)
                ptr += 1

    indptr.append(ptr)
    data = np.array(data)
    indices = np.array(indices)
    indptr = np.array(indptr)

    return data, indices, indptr

def csr_decompress(data, indices, indptr, shape):
    rows, cols = shape
    matrix = np.zeros(shape)

    for i in range(rows):
        start, end = indptr[i], indptr[i+1]
        for j in range(start, end):
            matrix[i, indices[j]] = data[j]

    return matrix

def compress_text_file(input_file, output_file):
    # Read input file and convert to matrix
    with open(input_file, 'r') as f:
        lines = f.readlines()
    words = [line.split() for line in lines]
    max_len = max(len(line) for line in words)
    matrix = np.zeros((len(words), max_len), dtype=np.int32)
    for i, line in enumerate(words):
        for j, word in enumerate(line):
            matrix[i,j] = hash(word) % 10000 + 1  # Hash word to integer

    # Compress matrix using CSR algorithm
    data, indices, indptr = csr_compress(matrix)

    # Write compressed data to output file
    with open(output_file, 'wb') as f:
        np.savez_compressed(f, data=data, indices=indices, indptr=indptr, shape=matrix.shape)

def decompress_text_file(input_file, output_file):
    # Read compressed data from input file
    with open(input_file, 'rb') as f:
        compressed_data = np.load(f)

        # Decompress data using CSR algorithm
        data = compressed_data['data']
        indices = compressed_data['indices']
        indptr = compressed_data['indptr']
        shape = compressed_data['shape']
        matrix = csr_decompress(data, indices, indptr, shape)

    # Convert matrix back to text and write to output file
    with open(output_file, 'w') as f:
        for i in range(matrix.shape[0]):
            line = ' '.join(str(word) for word in matrix[i] if word != 0)
            f.write(line + '\n')

# Example usage:
compress_text_file('new_file1.txt', 'compressed.npz')
decompress_text_file('compressed.npz', 'output.txt')
